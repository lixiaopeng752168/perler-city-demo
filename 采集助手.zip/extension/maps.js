'use strict';
function unfold(){const card=document.querySelector('#cards-level1 > .card.fold');if(card)card.click();}
chrome.runtime.onMessage.addListener((msg,sender,reply)=>{
 if(sender.id!==chrome.runtime.id||msg.channel!=='PERLER_MAP')return;
 try{
  if(msg.action==='search'){
   const input=document.querySelector('#sole-input'),button=document.querySelector('#search-button');
   if(!input||!button)throw Error('地图搜索框尚未加载，请稍后重试');
   Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,'value').set.call(input,msg.query);
   input.dispatchEvent(new Event('input',{bubbles:true}));input.dispatchEvent(new Event('change',{bubbles:true}));button.click();reply({ok:true});
  }else if(msg.action==='read'){
   unfold();reply({ok:true,...PerlerParser.parsePage(document,location.href)});
  }else if(msg.action==='next'){
   unfold();const next=[...document.querySelectorAll('#poi_page a')].find(a=>a.getAttribute('tid')==='toNextPage'||/下一页/.test(a.textContent));
   if(!next)throw Error('没有下一页按钮');next.click();reply({ok:true});
  }else throw Error('未知地图操作');
 }catch(e){reply({ok:false,error:e.message})}
});
