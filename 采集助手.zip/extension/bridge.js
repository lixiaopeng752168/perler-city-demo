'use strict';
const allowed=new Set(['ping','status','results','start','pause','resume','stop','open-map','clear-finished']);
window.addEventListener('message',async event=>{
 if(event.source!==window||event.origin!==location.origin)return;
 const m=event.data;if(!m||m.type!=='PERLER_REQUEST'||typeof m.id!=='string'||!allowed.has(m.action))return;
 try{const response=await chrome.runtime.sendMessage({...m,channel:'PERLER_CONTROL'});window.postMessage({type:'PERLER_RESPONSE',id:m.id,...response},location.origin);}
 catch(e){window.postMessage({type:'PERLER_RESPONSE',id:m.id,ok:false,error:e.message},location.origin);}
});
