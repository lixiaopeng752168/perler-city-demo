(function(root){
 'use strict';
 const STATUS={RUNNING:'运行中',PAUSED:'已暂停',DONE:'已完成',STOPPED:'已停止',WAIT:'等待处理'};
 function validateTask(raw){
  if(!raw||!Array.isArray(raw.cities)||!raw.cities.length||raw.cities.length>500)throw Error('请选择 1–500 个城市');
  const cities=raw.cities.map(c=>{if(!c||!['id','name','province','level'].every(k=>typeof c[k]==='string'&&c[k].length&&c[k].length<100))throw Error('城市字段无效');return {id:c.id,name:c.name,province:c.province,level:c.level}});
  const words=(a,n)=>{if(!Array.isArray(a)||a.length>n||a.some(s=>typeof s!=='string'||!s.trim()||s.length>60))throw Error('关键词或排除词无效');return [...new Set(a.map(s=>s.trim()))]};
  const keywords=words(raw.keywords,10);if(!keywords.length)throw Error('至少填写一个关键词');
  return {id:'task-'+Date.now()+'-'+Math.random().toString(36).slice(2,8),name:String(raw.name||'拼豆门店采集').slice(0,60),cities,keywords,exclude:words(raw.exclude||[],30),dedupe:raw.dedupe!==false,maxPages:Math.min(50,Math.max(1,Number(raw.maxPages)||10)),intervalMs:Math.min(30000,Math.max(3000,(Number(raw.intervalSec)||5)*1000)),levels:[...new Set(cities.map(c=>c.level))],status:STATUS.RUNNING,cityIndex:0,keywordIndex:0,page:1,stage:'search',done:0,added:0,seen:0,pagesRead:0,truncated:0,logs:[],createdAt:new Date().toISOString(),updatedAt:new Date().toISOString(),nextAt:0,waitSince:0,previousFingerprint:'',query:'',results:[],tabId:null};
 }
 function key(r,city){return r.poiUid?'baidu-'+r.poiUid:'text-'+city.id+'-'+r.name+'|'+r.address}
 function appendPage(task,page){
  const city=task.cities[task.cityIndex],keyword=task.keywords[task.keywordIndex];let added=0;
  const existing=new Set(task.results.map(r=>r.identity));
  for(const r of page.records){task.seen++;if(task.exclude.some(w=>(r.name+' '+r.address).includes(w)))continue;const identity=key(r,city);
   if(task.dedupe&&existing.has(identity)){const prior=task.results.find(s=>s.identity===identity);prior.keywords=[...new Set([...prior.keywords,keyword])];continue}
   const s={...r,identity,uid:task.dedupe?identity:identity+'-'+task.results.length,city:city.name,searchCity:city.name,mapCity:page.mapCity||'',province:city.province,level:city.level,keyword,keywords:[keyword],review:'待核验',source:'百度地图网页',collectedAt:new Date().toISOString(),taskId:task.id,lat:null,lng:null};task.results.push(s);existing.add(identity);added++;
  }
  task.added=task.results.length;task.pagesRead++;return added;
 }
 function advance(task){task.keywordIndex++;if(task.keywordIndex>=task.keywords.length){task.keywordIndex=0;task.cityIndex++;task.done=task.cityIndex;}task.page=1;task.stage='search';task.previousFingerprint='';task.waitSince=0;
  if(task.cityIndex>=task.cities.length){task.status=STATUS.DONE;task.stage='done';}
 }
 function cityMatches(name,mapCity){if(!mapCity)return false;const normalize=s=>s.replace(/藏族|回族|蒙古族|哈萨克族|维吾尔族|苗族|布依族|土家族|傣族|景颇族|朝鲜族|柯尔克孜族|白族|彝族|壮族|侗族|黎族|傈僳族|佤族|羌族|哈尼族|傣族|布朗族/g,'').replace(/地区$|市$|盟$/,'').replace(/自治州$|州$/,'');return normalize(name)===normalize(mapCity);}
 root.PerlerCore={STATUS,validateTask,key,appendPage,advance,cityMatches};if(typeof module!=='undefined')module.exports=root.PerlerCore;
})(typeof globalThis!=='undefined'?globalThis:this);

