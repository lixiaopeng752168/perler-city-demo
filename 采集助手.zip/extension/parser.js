(function(root){
 'use strict';
 const clean=s=>String(s||'').replace(/\s+/g,' ').trim();
 function parsePage(doc,url){
  const items=[...doc.querySelectorAll('#left-panel .poilist > li.search-item')];
  const records=items.map(el=>{
   const name=clean(el.querySelector('a[data-stat-code$=".title"],a.n-blue')?.textContent);
   const addr=el.querySelector('.addr [title],.addr');
   const address=clean(addr?.getAttribute('title')||addr?.textContent);
   const phone=clean(el.querySelector('.tel')?.textContent).replace(/^电话\s*[:：]\s*/,'');
   let poiUid='';
   for(const a of el.querySelectorAll('a[href]')){try{const uid=new URL(a.getAttribute('href'),url).searchParams.get('uid');if(uid&&/^[a-z0-9]{10,64}$/i.test(uid)){poiUid=uid;break}}catch{}}
   return {name,address,phone,poiUid,mapUrl:poiUid?'https://map.baidu.com/?s=inf%26uid%3D'+encodeURIComponent(poiUid):'https://map.baidu.com/search/'+encodeURIComponent(name),sourceUrl:url};
  }).filter(r=>r.name);
  const cur=Number(clean(doc.querySelector('#poi_page .curPage')?.textContent))||1;
  const next=[...doc.querySelectorAll('#poi_page a')].find(a=>a.getAttribute('tid')==='toNextPage'||/下一页/.test(a.textContent));
  const noText=clean(doc.querySelector('.poi-no-result')?.textContent);
  const leftText=clean(doc.querySelector('#left-panel')?.textContent);
  const blocked=/安全验证|请完成验证|访问过于频繁|操作过于频繁|异常访问|验证后继续|登录后才能|登录后可查看/.test(leftText);
  const noResults=Boolean(noText&&/没有|未找到|无结果|暂无|抱歉/.test(noText))||(!records.length&&/没有找到|未找到相关|没有相关|暂无搜索结果|抱歉.{0,30}未找到/.test(leftText));
  let urlQuery='';try{urlQuery=new URL(url).searchParams.get('wd')||''}catch{}
  return {records,page:cur,hasNext:Boolean(next&&!next.closest('.disabled')&&next.getAttribute('aria-disabled')!=='true'),noResults,blocked,query:doc.querySelector('#sole-input')?.value||'',urlQuery,mapCity:clean(doc.querySelector('#ui3_city_change a')?.textContent),fingerprint:records.map(r=>r.poiUid||r.name+'|'+r.address).join('\n')};
 }
 root.PerlerParser={parsePage,clean};
 if(typeof module!=='undefined')module.exports=root.PerlerParser;
})(typeof globalThis!=='undefined'?globalThis:this);
