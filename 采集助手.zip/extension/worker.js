'use strict';
importScripts('core.js');
const VERSION='1.0.0',ALARM='perler-collector';
let cached,loading,busy=false,timer,writes=Promise.resolve(),commands=Promise.resolve();
async function load(){if(cached)return cached;if(!loading)loading=chrome.storage.local.get('perlerDB').then(r=>cached=r.perlerDB||{tasks:[],activeId:null});return loading;}
function log(t,message){t.logs.unshift(new Date().toLocaleTimeString('zh-CN',{hour12:false})+' '+message);t.logs=t.logs.slice(0,100);}
function save(){cached.tasks.forEach(t=>t.updatedAt=new Date().toISOString());const snapshot=structuredClone(cached);writes=writes.catch(()=>{}).then(()=>chrome.storage.local.set({perlerDB:snapshot}));return writes;}
function summaries(db){return db.tasks.map(({results,...t})=>({...t,resultCount:results.length}));}
async function ensureAlarm(){if(!await chrome.alarms.get(ALARM))await chrome.alarms.create(ALARM,{periodInMinutes:.5});}
function schedule(ms=1000){clearTimeout(timer);timer=setTimeout(()=>tick(),ms);}
async function map(t,action,extra={}){const r=await chrome.tabs.sendMessage(t.tabId,{channel:'PERLER_MAP',action,...extra});if(!r||!r.ok)throw Error(r?.error||'百度地图页面未就绪');return r;}
async function ensureTab(t){
 if(t.tabId!==null){try{const tab=await chrome.tabs.get(t.tabId);if(new URL(tab.url).hostname==='map.baidu.com')return tab.id;}catch{}t.tabId=null;}
 const win=await chrome.windows.create({url:'https://map.baidu.com/',type:'normal',width:1180,height:820});t.tabId=win.tabs[0].id;return t.tabId;
}
async function pauseError(t,message){t.status=PerlerCore.STATUS.WAIT;log(t,message+'；在地图窗口处理后点击“继续”。');await save();}
async function tick(){
 if(busy)return;busy=true;
 try{
  const db=await load(),t=db.tasks.find(t=>t.id===db.activeId);
  if(!t||t.status!==PerlerCore.STATUS.RUNNING)return;
  if(Date.now()<t.nextAt){schedule(Math.min(5000,t.nextAt-Date.now()));return;}
  if(new TextEncoder().encode(JSON.stringify(db)).length>7000000){await pauseError(t,'本机采集存储接近上限，请先导出并备份历史任务');return;}
  if(t.stage==='search'){
   await ensureTab(t);const tab=await chrome.tabs.get(t.tabId);if(tab.status!=='complete'){t.nextAt=Date.now()+1500;schedule(1500);await save();return;}
   t.query=t.cities[t.cityIndex].name+t.keywords[t.keywordIndex];
   try{await map(t,'search',{query:t.query});}catch(e){if(!t.waitSince)t.waitSince=Date.now();if(Date.now()-t.waitSince>30000){await pauseError(t,e.message);return;}t.nextAt=Date.now()+1500;schedule(1500);await save();return;}
   if(t.status!==PerlerCore.STATUS.RUNNING)return;
   t.stage='read';t.waitSince=Date.now();t.nextAt=Date.now()+t.intervalMs;log(t,'搜索 '+t.query);await save();schedule(t.intervalMs);return;
  }
  if(t.stage==='next'){
   await map(t,'next');if(t.status!==PerlerCore.STATUS.RUNNING)return;t.page++;t.stage='read';t.waitSince=Date.now();t.nextAt=Date.now()+t.intervalMs;await save();schedule(t.intervalMs);return;
  }
  const result=await map(t,'read');if(t.status!==PerlerCore.STATUS.RUNNING)return;
  if(result.blocked){await pauseError(t,'地图要求登录或验证，已暂停采集');return;}
  const ready=result.urlQuery===t.query&&(result.noResults||(result.records.length&&result.page===t.page&&(t.page===1||result.fingerprint!==t.previousFingerprint)));
  if(!ready){if(Date.now()-t.waitSince>30000){await pauseError(t,'30 秒内未读取到对应搜索结果，可能网络慢或地图页面发生变化');return;}t.nextAt=Date.now()+1500;await save();schedule(1500);return;}
  if(!PerlerCore.cityMatches(t.cities[t.cityIndex].name,result.mapCity)){await pauseError(t,'地图当前城市“'+(result.mapCity||'未知')+'”与任务城市“'+t.cities[t.cityIndex].name+'”不一致，请在地图切换城市');return;}
  const added=PerlerCore.appendPage(t,result);log(t,t.query+' 第 '+t.page+' 页：读取 '+result.records.length+'，新增 '+added+' 条');
  t.previousFingerprint=result.fingerprint;
  if(result.hasNext&&t.page<t.maxPages){t.stage='next';}
  else{
   if(result.hasNext){t.truncated++;log(t,'达到 '+t.maxPages+' 页上限，本组结果未全量采集');}
   PerlerCore.advance(t);if(t.status===PerlerCore.STATUS.DONE){db.activeId=null;log(t,'任务结束，保留 '+t.results.length+' 条真实候选门店'+(t.truncated?'；有 '+t.truncated+' 组达到页数上限':''));}
  }
  t.nextAt=Date.now()+t.intervalMs;await save();if(t.status===PerlerCore.STATUS.RUNNING)schedule(t.intervalMs);
 }catch(e){const db=await load(),t=db.tasks.find(t=>t.id===db.activeId);if(t&&t.status===PerlerCore.STATUS.RUNNING)await pauseError(t,e.message||'采集异常');}
 finally{busy=false;}
}
function trusted(sender){try{const u=new URL(sender.url||'');return (u.protocol==='chrome-extension:'&&u.hostname===chrome.runtime.id&&u.pathname==='/panel/index.html')||(u.origin==='https://lixiaopeng752168.github.io'&&u.pathname.startsWith('/perler-city-demo/'));}catch{return false;}}
async function command(message,sender){
 if(message.channel!=='PERLER_CONTROL'||!trusted(sender))throw Error('不允许的采集来源');
 const db=await load();await ensureAlarm();const active=db.tasks.find(t=>t.id===db.activeId);
 switch(message.action){
  case 'ping':return {version:VERSION};
  case 'status':schedule(100);return {version:VERSION,tasks:summaries(db),activeId:db.activeId};
  case 'results':{const t=db.tasks.find(t=>t.id===message.taskId);if(!t)throw Error('任务不存在');const offset=Math.max(0,Number(message.offset)||0);return {rows:t.results.slice(offset,offset+500),total:t.results.length};}
  case 'start':{
   if(active&&[PerlerCore.STATUS.RUNNING,PerlerCore.STATUS.PAUSED,PerlerCore.STATUS.WAIT].includes(active.status))throw Error('已有未结束的任务，请继续或停止当前任务');
   if(db.tasks.length>=30)throw Error('历史任务已达 30 个，请备份后在设置中清理已结束任务');
   const t=PerlerCore.validateTask(message.task);db.tasks.push(t);db.activeId=t.id;log(t,'任务已创建；从百度地图网页读取真实结果');await save();schedule(100);return {task:{...t,results:undefined}};
  }
  case 'pause':if(!active||active.id!==message.taskId||active.status!==PerlerCore.STATUS.RUNNING)throw Error('当前任务不在运行中');active.status=PerlerCore.STATUS.PAUSED;log(active,'用户暂停，已采集结果保留');await save();return {};
  case 'resume':{
   const t=db.tasks.find(t=>t.id===message.taskId);if(!t||![PerlerCore.STATUS.PAUSED,PerlerCore.STATUS.WAIT].includes(t.status))throw Error('该任务不能继续');
   if(active&&active.id!==t.id)throw Error('请先停止当前任务');
   t.status=PerlerCore.STATUS.RUNNING;t.waitSince=Date.now();t.nextAt=0;db.activeId=t.id;log(t,'用户继续采集');await save();schedule(100);return {};
  }
  case 'stop':if(!active||active.id!==message.taskId)throw Error('没有对应的活动任务');active.status=PerlerCore.STATUS.STOPPED;db.activeId=null;log(active,'用户停止；已采集结果保留');await save();return {};
  case 'open-map':if(active){await ensureTab(active);await chrome.tabs.update(active.tabId,{active:true});const tab=await chrome.tabs.get(active.tabId);await chrome.windows.update(tab.windowId,{focused:true});await save();}else await chrome.tabs.create({url:'https://map.baidu.com/'});return {};
  case 'clear-finished':db.tasks=db.tasks.filter(t=>[PerlerCore.STATUS.RUNNING,PerlerCore.STATUS.PAUSED,PerlerCore.STATUS.WAIT].includes(t.status));await save();return {};
  default:throw Error('未知采集命令');
 }
}
chrome.runtime.onMessage.addListener((message,sender,reply)=>{if(message.channel!=='PERLER_CONTROL')return;commands=commands.catch(()=>{}).then(()=>command(message,sender));commands.then(data=>reply({ok:true,...data})).catch(e=>reply({ok:false,error:e.message}));return true;});
chrome.alarms.onAlarm.addListener(alarm=>{if(alarm.name===ALARM)tick();});
chrome.runtime.onInstalled.addListener(()=>{ensureAlarm();});
chrome.runtime.onStartup.addListener(async()=>{const db=await load();for(const t of db.tasks){if(t.status===PerlerCore.STATUS.RUNNING){t.status=PerlerCore.STATUS.PAUSED;t.stage='search';t.page=1;t.tabId=null;log(t,'浏览器重新启动，任务已暂停；继续时重搜当前城市关键词并去重');}}await save();await ensureAlarm();});
chrome.action.onClicked.addListener(()=>chrome.tabs.create({url:chrome.runtime.getURL('panel/index.html')}));
chrome.tabs.onRemoved.addListener(async tabId=>{const db=await load(),t=db.tasks.find(t=>t.id===db.activeId);if(t&&t.tabId===tabId){t.tabId=null;t.stage='search';t.page=1;t.waitSince=0;if(t.status===PerlerCore.STATUS.RUNNING)t.status=PerlerCore.STATUS.WAIT;log(t,'采集地图窗口已关闭；继续时会重新打开并重搜当前关键词');await save();}});
